

/*------------------------- Transaction Operations--------------------------------------------------------------------------------- */

/*-------------- Example Transaction 1 -----------------------------------------*/
## E.g., Transaction Operation1: Failed due to the CHECK constraint & Rolled back
# Begin the transaction
START TRANSACTION;

# Update a vital record for a specific patient & date
UPDATE self_vitals_records_data
SET blood_pressure = 130
WHERE patient_id = 1 AND date_of_vital_record = '2025-02-08';

# Update a prescription record for the same patient & date
UPDATE prescriptions_data
SET prescription_recommended_x_times_per_day = 4
WHERE patient_id = 1 AND date_of_record = '2025-02-08';

# If both updates succeed, commit the changes
COMMIT;

# If an error occurs, then roll back:
ROLLBACK;

-- -----------------------------------------------------------------------------

/*-------------- Example Transaction 2 ----------------------------------------------------*/
## E.g., Transaction Operation2: Passed & Committed
# Begin the transaction
START TRANSACTION;

# Update an appointment's status to 'Completed'
UPDATE appointments
SET appointment_status = 'Completed'
WHERE appointment_id = 6;

# Update the patient's diagnosis recommendation in patient_detail_record
UPDATE patient_detail_record
SET diagnosis_recommendation = 'Medication prescribed after appointment'
WHERE patient_id = (Select patient_id FROM appointments WHERE appointment_id = 6)
AND patient_date_of_visit = (Select appointment_date FROM appointments WHERE appointment_id = 6);

# If both updates succeed, commit the changes
COMMIT;

# If an error occurs, roll back all changes:
ROLLBACK;
-- ---------------------------------------------------------------------------------------------

/*-------------- Example Transaction 3 -----------------------------------------------------------------------*/
## E.g., Transaction Operation3: Failed due to a foreign key constraint & Rolled back
# Begin the transaction
START TRANSACTION;

# Update an appointment's status to 'Completed'
UPDATE appointments
SET appointment_status = 'Completed'
WHERE appointment_id = 7;  -- Assuming appointment_id = 7 exists

# Attempt to update patient_detail_record with a non-existent doctor_id
UPDATE patient_detail_record
SET doctor_id = 9999
WHERE patient_id = 3
  AND patient_date_of_visit = '2025-02-22';

# If both updates succeed, then commit
COMMIT;

# If error occurs, roll back
ROLLBACK;
-- --------------------------------------------------------------------------------------------------------------
-- -------------------------------------------------------------XXXXXXXXXXXXXXXXXXXXXXXX------------------------------------------------------