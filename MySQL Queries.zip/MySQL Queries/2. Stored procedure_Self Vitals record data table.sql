

DELIMITER //

CREATE PROCEDURE UpdateVitalsStatusForPatient(IN p_patient_id INT)
BEGIN
    -- Update Blood Glucose Status
    UPDATE self_vitals_records_data
    SET blood_glucose_status = 
        CASE 
            WHEN blood_glucose BETWEEN 60 AND 126 THEN 'Normal Range'
            WHEN blood_glucose < 60 THEN 'Low Blood Sugar'
            WHEN blood_glucose > 126 THEN 'High Blood Sugar'
        END
    WHERE patient_id = p_patient_id;

    -- Update Blood Pressure Status
    UPDATE self_vitals_records_data
    SET blood_pressure_status = 
        CASE 
            WHEN blood_pressure BETWEEN 90 AND 140 THEN 'Normal Range'
            WHEN blood_pressure < 90 THEN 'Low Blood Pressure'
            WHEN blood_pressure > 140 THEN 'High Blood Pressure'
        END
    WHERE patient_id = p_patient_id;

    -- Update Body Temperature Status (Assuming °C to °F conversion)
    UPDATE self_vitals_records_data
    SET body_temp_status = 
        CASE 
            WHEN (body_temp * 9/5 + 32) BETWEEN 95 AND 100 THEN 'Normal Range'
            WHEN (body_temp * 9/5 + 32) < 95 THEN 'Low Body Temperature'
            WHEN (body_temp * 9/5 + 32) > 100 THEN 'High Body Temperature'
        END
    WHERE patient_id = p_patient_id;

    -- Update Heart Rate Status
    UPDATE self_vitals_records_data
    SET heart_rate_status = 
        CASE 
            WHEN heart_rate BETWEEN 40 AND 130 THEN 'Normal Range'
            WHEN heart_rate < 40 THEN 'Low Heart Rate'
            WHEN heart_rate > 130 THEN 'High Heart Rate'
        END
    WHERE patient_id = p_patient_id;

    -- Update Oxygen Saturation Status
    UPDATE self_vitals_records_data
    SET oxygen_saturation_status = 
        CASE 
            WHEN oxygen_saturation BETWEEN 88 AND 92 THEN 'Normal Range'
            WHEN oxygen_saturation < 88 THEN 'Low Oxygen Level'
            WHEN oxygen_saturation > 92 THEN 'High Oxygen Level'
        END
    WHERE patient_id = p_patient_id;

    -- Update Respiratory Rate Status
    UPDATE self_vitals_records_data
    SET respiratory_rate_status = 
        CASE 
            WHEN respiratory_rate BETWEEN 8 AND 30 THEN 'Normal Range'
            WHEN respiratory_rate < 8 THEN 'Low Respiratory Rate'
            WHEN respiratory_rate > 30 THEN 'High Respiratory Rate'
        END
    WHERE patient_id = p_patient_id;
END //

DELIMITER ;





