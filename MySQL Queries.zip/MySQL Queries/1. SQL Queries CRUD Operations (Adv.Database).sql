
/*------------------------- Create the database ---------------------------------------- */

create database ehr_portal;

use ehr_portal;
-- ------------------------------XXXXXXXXXXXXXXX-----------------------------------------

/*------------------------- Create the tables (CRUD operations)-------------------------------------------------------------*/

# doctor detail table
CREATE TABLE doctor_record (
    doctor_id BIGINT NOT NULL,
    doctor_name VARCHAR(255) NULL,
    doctor_gender VARCHAR(255) NULL,
    doctor_email VARCHAR(255) NULL,
    doctor_phone VARCHAR(255) NULL,
    date_of_visit DATE NOT NULL,
    time_of_visit TIME NOT NULL,
    purpose_of_visit VARCHAR(255) NULL,
    diagnosis_recommendation VARCHAR(255) NULL,
    patient_id BIGINT NOT NULL, 
    patient_age INT NULL,
    patient_medical_docs VARCHAR(255) NULL,
    visit_id BIGINT NOT NULL AUTO_INCREMENT,
    PRIMARY KEY (visit_id),
	UNIQUE KEY unique_doc_visit (doctor_id, date_of_visit, time_of_visit)
);

# patient detail table
CREATE TABLE patient_detail_record (
    patient_id BIGINT NOT NULL,
    patient_name VARCHAR(255) NULL,
    patient_gender VARCHAR(255) NULL,
    patient_email VARCHAR(255) NULL,
    patient_phone VARCHAR(255) NULL,
    patient_age INT NULL,
    patient_date_of_visit DATE NOT NULL,
    purpose_of_visit VARCHAR(255) NULL,
    diagnosis_recommendation VARCHAR(255) NULL,
    patient_medical_docs VARCHAR(255) NULL,
    doctor_id BIGINT NOT NULL,
    PRIMARY KEY (patient_id, patient_date_of_visit),
    KEY doctor_id_date_idx (doctor_id, patient_date_of_visit),
    CONSTRAINT fk_doctor_visit 
	FOREIGN KEY (doctor_id, patient_date_of_visit)
	REFERENCES doctor_record (doctor_id, date_of_visit)
);

-- SHOW CREATE TABLE patient_detail_record;

# patient vitals detail table
CREATE TABLE self_vitals_records_data (
    id BIGINT NOT NULL AUTO_INCREMENT,
    patient_id BIGINT NOT NULL,   
	patient_name VARCHAR(255) DEFAULT NULL,
    age INT NULL,
    height DOUBLE DEFAULT NULL,
    weight DOUBLE NULL,
	gender VARCHAR(255) DEFAULT NULL,
	blood_type VARCHAR(255) DEFAULT NULL,
    blood_glucose DOUBLE NULL,
    blood_glucose_status VARCHAR(255) NULL,
    blood_pressure INT NULL,
    blood_pressure_status VARCHAR(255) NULL,
    body_temp DOUBLE NULL,
    body_temp_status VARCHAR(255) NULL,
    heart_rate INT NULL,
    heart_rate_status VARCHAR(255) NULL,
    oxygen_saturation DOUBLE NULL,
    oxygen_saturation_status VARCHAR(255) NULL,
    respiratory_rate INT NULL,
    respiratory_rate_status VARCHAR(255) NULL,
    date_of_vital_record DATE NOT NULL,
    time_of_vital_record TIME NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY unique_date_time (date_of_vital_record, time_of_vital_record),
	KEY idx_patient_id (patient_id),
    CONSTRAINT fk_patient_id FOREIGN KEY (patient_id) REFERENCES patient_detail_record (patient_id)
);

# patient prescription detail table
CREATE TABLE prescriptions_data (
    id BIGINT NOT NULL AUTO_INCREMENT,
    patient_id BIGINT NOT NULL,
    patient_name VARCHAR(255) NOT NULL,
	medicine_name VARCHAR(255) NOT NULL,
    date_of_record DATE NOT NULL,
    prescription_start_date VARCHAR(255) NOT NULL,
    prescription_end_date VARCHAR(255) NOT NULL,
    prescription_recommended_x_times_per_day INT NOT NULL,
    morning_slot VARCHAR(255) DEFAULT NULL,
    afternoon_slot VARCHAR(255) DEFAULT NULL,
    evening_slot VARCHAR(255) DEFAULT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY unique_patient_date (patient_id, date_of_record),
    KEY idx_patient_id (patient_id),
    CONSTRAINT fk_prescription_patient_id FOREIGN KEY (patient_id) REFERENCES patient_detail_record (patient_id)
);


##--- For table prescriptions_data - Restricting the Column via a CHECK Constraint or Application Logic ---##
# This enforces valid input at the database level, rejecting any value outside 1–3
ALTER TABLE prescriptions_data
ADD CONSTRAINT chk_times_per_day
CHECK (prescription_recommended_x_times_per_day IN (1, 2, 3));


# appointment detail table
CREATE TABLE appointments (
    appointment_id BIGINT NOT NULL AUTO_INCREMENT,
    doctor_id BIGINT NOT NULL,
    patient_id BIGINT NOT NULL,
    appointment_date DATE NOT NULL,
    appointment_time TIME NOT NULL,
	appointment_status VARCHAR(255) NULL,
    reason_for_visit VARCHAR(255) NULL,
    additional_notes VARCHAR(255) NULL,
    PRIMARY KEY (appointment_id),
    UNIQUE KEY unique_patient_date (patient_id, appointment_date),
    KEY doctor_id_index (doctor_id),
    KEY patient_id_index (patient_id),
    CONSTRAINT fk_doctor_id FOREIGN KEY (doctor_id) REFERENCES doctor_record (doctor_id),
    CONSTRAINT fk_app_patient_id FOREIGN KEY (patient_id) REFERENCES patient_detail_record (patient_id)
);

-- -------------------------------------------XXXXXXXXXXXXXXX--------------------------------------------------------------------

/*------------------------- Insert Values in the tables (CRUD operations)---------------------------------------------------------------------------------------------------- */

## Firstly insert patient_id & doctor_id into the doctor_record data. Then, use the same doctor_id to insert records into the patient_detail_record table
# Patient 1, First visit on 2025-02-08
INSERT INTO doctor_record (
    doctor_id, doctor_name, doctor_gender, doctor_email, doctor_phone,
    date_of_visit, time_of_visit, purpose_of_visit, diagnosis_recommendation,
    patient_id, patient_age, patient_medical_docs
)
VALUES (1, 'Dr. Christopher Lee', 'Male', 'dr.lee@example.com', '+49-1100000011', 
		'2025-02-08', '08:00', 'General Consultation', 'Take medication as prescribed',
		1, 45, 'blood report.pdf');
    
# Second visit on 2025-02-15 of the same patient, to the same doctor
INSERT INTO doctor_record (
    doctor_id, doctor_name, doctor_gender, doctor_email, doctor_phone,
    date_of_visit, time_of_visit, purpose_of_visit, diagnosis_recommendation,
    patient_id, patient_age, patient_medical_docs
)
VALUES (1, 'Dr. Christopher Lee', 'Male', 'dr.lee@example.com', '+49-1100000011', 
		'2025-02-15', '09:00', 'General Consultation', 'Take medication as prescribed',
		1, 45, 'blood report.pdf');


# Once patient_id, doctor_id, and date_of_visit are inserted into doctor_record, they can be used here for insertion, with doctor_id and date_of_visit being validated against their foreign key constraints in doctor_record.
INSERT INTO patient_detail_record (
    patient_id, patient_name, patient_gender, patient_email, 
    patient_phone, patient_age, patient_date_of_visit, purpose_of_visit, 
    diagnosis_recommendation, patient_medical_docs, doctor_id
)
VALUES (1, 'John Doe', 'Male', 'john.doe@example.com', '+49-1234567890', 45, '2025-02-08', 
	    'General Consultation', 'Take medication as prescribed', 'Blood Report.pdf', 1);


# Insert value for Self Vital Records  -- Example: Patient 1: John Doe (Male, 45)
INSERT INTO self_vitals_records_data (
    patient_id, patient_name, age, height, weight, gender, blood_type,
    blood_glucose, blood_pressure, body_temp, heart_rate, oxygen_saturation,
    respiratory_rate, date_of_vital_record, time_of_vital_record
)
VALUES (
    1,                   -- patient_id
    'John Doe',          -- patient_name
    45,                  -- age
    170,                 -- height in cm
    70,                  -- weight in kg
    'Male',              -- gender
    'B+',                -- blood_type
    90,                  -- blood_glucose
    120,                 -- blood_pressure
    36.7,                -- body_temp in °C
    72,                  -- heart_rate
    98,                  -- oxygen_saturation
    16,                  -- respiratory_rate
    '2025-02-08',        -- date_of_vital_record
    '08:00'              -- time_of_vital_record
);


# Calling stored procedure to update the vital status columns
CALL UpdateVitalsStatusForPatient(1);



# Insert value for prescriptions_data
INSERT INTO prescriptions_data (
    patient_id, patient_name, medicine_name, date_of_record, prescription_start_date, 
    prescription_end_date, prescription_recommended_x_times_per_day
)
VALUES (1, 'John Doe', 'Paracetamol',
    '2025-02-08',    -- date when the prescription is recorded
    '2025-02-09',    -- prescription start date as stored (VARCHAR)
    '2025-02-11',    -- prescription end date as stored (VARCHAR)
    3             
);

# Calling stored procedure to update the dosage time slots columns
CALL UpdatePrescriptionSlots(1);

# Insert appointment details
INSERT INTO appointments (
    doctor_id, patient_id, appointment_date, appointment_time,
    appointment_status, reason_for_visit, additional_notes
)
VALUES (
    1,                        -- doctor_id (must exist in doctor_record)
    1,                        -- patient_id (must exist in patient_detail_record)
    '2025-02-08',             -- appointment_date
    '09:30:00',               -- appointment_time
    'Completed',              -- appointment_status (Completed/Scheduled/Canceled)
    'General Consultation',   -- reason_for_visit
    'No additional notes'     -- additional_notes
);

-- -----------------------------------------------XXXXXXXXXXXXXXXXXX-----------------------------------------------------------------------------------------------------------------------------------


/*------------------------- Read/Select Values from the tables (CRUD operations)-------------------------------------------------------------- */

####------------------- 1. doctor_record Table ----------------------------------------####
## 1.1 Select All Columns
# Retrieve all columns for all doctor visits
SELECT *
FROM ehr_portal.doctor_record;

## 1.2 Filter by Doctor ID
# Get all records for doctor_id = 1
SELECT doctor_id, doctor_name, date_of_visit, time_of_visit, purpose_of_visit
FROM doctor_record
WHERE doctor_id = 1;


## 1.3 Filter by Patient ID
# Get all records for patient_id = 1
SELECT doctor_id, doctor_name, date_of_visit, time_of_visit, purpose_of_visit
FROM doctor_record
WHERE patient_id = 1;


## 1.4 Order by Visit Date and Time
# Show doctor visits in chronological order
SELECT doctor_id, doctor_name, date_of_visit, time_of_visit
FROM doctor_record
ORDER BY date_of_visit, time_of_visit;


## 1.5 Count Visits per Doctor
# Count how many visits each doctor has
SELECT doctor_id, doctor_name, COUNT(*) AS total_visits
FROM doctor_record
GROUP BY doctor_id, doctor_name
ORDER BY total_visits DESC;
-- -----------------------------------XXXXX--------------------------------------------------------------

####--------------------- 2. patient_detail_record Table ---------------------------------------#####
## 2.1 Select All Columns
# Retrieve all patient details
SELECT *
FROM patient_detail_record;

## 2.2 Filter by Date Range
# Find patients who visited between two dates
SELECT patient_id, patient_name, patient_date_of_visit, purpose_of_visit
FROM patient_detail_record
WHERE patient_date_of_visit BETWEEN '2025-02-10' AND '2025-02-20';


## 2.3 Search by Patient Name
# Case-insensitive search for patients named 'john'
SELECT patient_id, patient_name, patient_date_of_visit
FROM patient_detail_record
WHERE LOWER(patient_name) LIKE '%john%';


## 2.4 Join with doctor_record
# Show patient and doctor info together
SELECT p.patient_id,
       p.patient_name,
       p.patient_date_of_visit,
       d.doctor_name,
       d.date_of_visit
FROM patient_detail_record p
JOIN doctor_record d
  ON p.doctor_id = d.doctor_id
 AND p.patient_date_of_visit = d.date_of_visit
ORDER BY p.patient_date_of_visit;
-- -----------------------------------XXXXXXX------------------------------------------------------------

####---------------------------- 3. patient_detail_record Table ------------------------------------------####
## 3.1 Select All Columns
# Retrieve all vital records
SELECT *
FROM self_vitals_records_data;

## Filter by Patient ID
# Get vital records for a specific patient (e.g., patient_id = 1)
SELECT patient_id, patient_name, blood_glucose, blood_pressure, date_of_vital_record, time_of_vital_record
FROM self_vitals_records_data
WHERE patient_id = 1;


## Order by Date and Time
# Show vital records in chronological order for all patients
SELECT patient_id, patient_name, date_of_vital_record, time_of_vital_record,
       blood_glucose, blood_pressure
FROM self_vitals_records_data
ORDER BY date_of_vital_record, time_of_vital_record;


## Filter by Status
# Show all records where blood_glucose_status = 'High Blood Sugar'
SELECT patient_id, patient_name, blood_glucose, blood_glucose_status
FROM self_vitals_records_data
WHERE blood_glucose_status = 'High Blood Sugar';
-- ------------------------------------XXXXXXX-------------------------------------------------------------

####------------------ 4. prescriptions_data Table --------------------------------------------------####
## Select All Columns
# Retrieve all prescriptions
SELECT *
FROM prescriptions_data;


## Filter by Times per Day
# Show prescriptions that are recommended 3 times per day
SELECT patient_id, patient_name, medicine_name, prescription_recommended_x_times_per_day
FROM prescriptions_data
WHERE prescription_recommended_x_times_per_day = 3;


## Check Current Prescriptions
# Find prescriptions recorded on a specific date
SELECT patient_id, patient_name, medicine_name, date_of_record
FROM prescriptions_data
WHERE date_of_record = '2025-02-10';


## Show Morning Doses
# List patients who have a morning_slot recommended
SELECT patient_id, patient_name, medicine_name, morning_slot
FROM prescriptions_data
WHERE morning_slot IS NOT NULL
  AND morning_slot NOT LIKE '%Not recommended%';
-- ----------------------------------XXXXXXX---------------------------------------------------------------

####-------------------------------- 5. appointments Table ---------------------------------------------####
## Select All Columns
# Retrieve all appointments
SELECT *
FROM appointments;


## Filter by Appointment Status
# Show only 'Completed' appointments
SELECT appointment_id, doctor_id, patient_id, appointment_date, appointment_time
FROM appointments
WHERE appointment_status = 'Completed';


## Check Upcoming Appointments
# Show appointments on or after a certain date
SELECT appointment_id, doctor_id, patient_id, appointment_date, appointment_time, appointment_status
FROM appointments
WHERE appointment_date >= '2025-02-15'
ORDER BY appointment_date, appointment_time;


## Join with patient_detail_record
# Show appointments along with patient details
SELECT a.appointment_id,
       a.appointment_date,
       a.appointment_time,
       a.appointment_status,
       p.patient_name,
       p.patient_phone
FROM appointments a
JOIN patient_detail_record p
  ON a.patient_id = p.patient_id
WHERE p.patient_date_of_visit = a.appointment_date
ORDER BY a.appointment_date, a.appointment_time;
-- --------------------------------------------XXXXXXXXXXXXXXXXXXXXXXXXX----------------------------------------------------------------------


/*------------------------- Update Values from the tables (CRUD operations)------------------------------------------------------------ */

## 1. doctor_record Table --------------------------------------  
# Update the doctor's phone number for a specific doctor_id
UPDATE doctor_record
SET doctor_phone = '+49-3400000034'
WHERE doctor_id = 3;

SELECT doctor_id, doctor_phone 
FROM doctor_record
WHERE doctor_id = 3;


## 2. patient_detail_record Table ----------------------------
# Update the patient email for a specific patient id
UPDATE patient_detail_record
SET patient_email = 'charlie.davis1@example.com'
WHERE patient_id = 5 
AND patient_date_of_visit = '2025-02-20';

SELECT patient_id, patient_email, patient_date_of_visit
FROM patient_detail_record
WHERE patient_id = 5;


## 3. self_vitals_records_data Table --------------------------------------
# Update the blood pressure value for a patient id & date of vital record
UPDATE self_vitals_records_data
SET blood_pressure = 141, body_temp = 37.8  
WHERE patient_id = 2 AND Date_of_vital_record = '2025-02-10';

CALL UpdateVitalsStatusForPatient(2);                         # called stored precedure to update the vital status

SELECT patient_id, Date_of_vital_record, blood_pressure,      # select to show updated value
blood_pressure_status, body_temp, body_temp_status
FROM self_vitals_records_data
WHERE patient_id = 2 AND Date_of_vital_record = '2025-02-10';



## 4. prescriptions_data Table ----------------------------------------
# Update the prescription end date for a specific prescription record
UPDATE prescriptions_data
SET prescription_end_date = '2025-02-20'
WHERE patient_id = 3 AND Date_of_record = '2025-02-15';

SELECT patient_id, date_of_record, prescription_start_date, prescription_end_date
FROM prescriptions_data
WHERE patient_id = 3 AND date_of_record = '2025-02-15';


## 5. appointments Table ----------------------------------------------
# Update the appointment status for a given appointment
UPDATE appointments
SET appointment_status = 'Cancelled'
WHERE appointment_id = 8;

SELECT appointment_id, doctor_id, patient_id, appointment_status
FROM appointments
WHERE appointment_id = 8;

-- -----------------------------------------XXXXXXXXXXXXXXXXXXXXXXXX-------------------------------------------------------------------


/*------------------------- Delete Values from the tables (CRUD operations)-------------------------------------------- */
## Delete Dependent Records First:
#  Delete from self_vitals_records_data (Child of patient_detail_record)
DELETE FROM self_vitals_records_data
WHERE patient_id = 4;

#  Delete from prescriptions_data (Child of patient_detail_record)
DELETE FROM prescriptions_data
WHERE patient_id = 4;

# Delete from appointments (Child of both doctor_record and patient_detail_record)
DELETE FROM appointments
WHERE doctor_id = 5
AND patient_id = 4
AND appointment_date = '2025-02-25';

# Delete from patient_detail_record (Child of doctor_record)
DELETE FROM patient_detail_record
WHERE doctor_id = 5
AND patient_date_of_visit = '2025-02-25';


# Delete from doctor_record (Parent)
DELETE FROM doctor_record
WHERE doctor_id = 5
AND date_of_visit = '2025-02-25';

-- ----------------------------------------------XXXXXXXXXXXXXXXXXXXXXXX-------------------------------------------------



