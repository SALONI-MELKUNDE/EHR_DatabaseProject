


/*------------------------- JOIN Operations/JOIN Tables SQL Queries----------------------------------------------------------------------------- */
# First Use database 
USE ehr_portal;

# Example1: JOIN or INNER JOIN which return rows where matching records exist in both table
SELECT 
    d.doctor_id,
    d.doctor_name,
    d.date_of_visit,
    d.purpose_of_visit,
    p.patient_id,
    p.patient_name,
    p.patient_date_of_visit,
    p.diagnosis_recommendation
FROM doctor_record d
JOIN patient_detail_record p
    ON d.doctor_id = p.doctor_id 
    AND d.date_of_visit = p.patient_date_of_visit
ORDER BY d.date_of_visit;

-- -------------------------------------------------------------------------------------------------------------------------------------------------

# Example2: LEFT JOIN returns all rows from the left (first) table, even if no matching row is found in the right (second) table.

SELECT 
    d.doctor_id,
    d.doctor_name,
    d.date_of_visit,
    d.time_of_visit,
    d.purpose_of_visit,
    p.patient_id,
    p.patient_name,
    p.patient_date_of_visit,
    p.diagnosis_recommendation
FROM doctor_record d
LEFT JOIN patient_detail_record p
    ON d.doctor_id = p.doctor_id
   AND d.date_of_visit = p.patient_date_of_visit
ORDER BY d.date_of_visit;

-- -------------------------------------------------------------------------------------------------------------------------------------------------------

# Example3: INNER JOIN that combines patient_detail_record with self_vitals_records_data
SELECT 
    p.patient_id,
    p.patient_name,
    p.patient_date_of_visit,
    p.diagnosis_recommendation,
    s.id AS vitals_record_id,
    s.blood_pressure,
    s.blood_glucose,
    s.date_of_vital_record,
    s.time_of_vital_record
FROM patient_detail_record p
JOIN self_vitals_records_data s
    ON p.patient_id = s.patient_id
ORDER BY p.patient_date_of_visit, s.date_of_vital_record, s.time_of_vital_record;

-- -------------------------------------------------------------------------------------------------------------------------------------------------------
