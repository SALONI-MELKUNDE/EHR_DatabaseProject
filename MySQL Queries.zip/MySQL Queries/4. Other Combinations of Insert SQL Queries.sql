
/*------------------------- Insert Values in the tables - OTHER COMBINATIONS of Patients & Doctors (Demonstration of CRUD operations)---------------------------------------- */
# Doctor 2 -- Patient 2
INSERT INTO doctor_record (
    doctor_id,
    doctor_name,
    doctor_gender,
    doctor_email,
    doctor_phone,
    date_of_visit,
    time_of_visit,
    purpose_of_visit,
    diagnosis_recommendation,
    patient_id,
    patient_age,
    patient_medical_docs
)
VALUES (
    2,
    'Dr. Natalie Carter',
    'Female',
    'dr.carter@example.com',
    '+49-2200000022',
    '2025-02-10',
    '11:00',
    'Follow-up Consultation',
    'Rest and hydration',
    2,
    40,
    'ECG_report.pdf.pdf'
);

# Doctor 1 -- Patient 3
INSERT INTO doctor_record (
    doctor_id,
    doctor_name,
    doctor_gender,
    doctor_email,
    doctor_phone,
    date_of_visit,
    time_of_visit,
    purpose_of_visit,
    diagnosis_recommendation,
    patient_id,
    patient_age,
    patient_medical_docs
)
VALUES
(
    1,
    'Dr. Christopher Lee',
    'Male',
    'dr.lee@example.com',
    '+49-1100000011',
    '2025-02-15',
    '12:30',
    'Examination',
    'Follow-up and further tests',
    3,
    10,
    'Examination_report.pdf'
);
-- ----------------------------------------------------------------------------------------------------------------

###------- Below is a single INSERT statement that adds all five records into the doctor_record table-------------###
# Doctor & Patient combinations
INSERT INTO doctor_record (
    doctor_id,
    doctor_name,
    doctor_gender,
    doctor_email,
    doctor_phone,
    date_of_visit,
    time_of_visit,
    purpose_of_visit,
    diagnosis_recommendation,
    patient_id,
    patient_age,
    patient_medical_docs
)
VALUES
(
    3,
    'Dr. Alex Carry',
    'Male',
    'dr.carry@example.com',
    '+49-3300000033',
    '2025-02-17',
    '13:00',
    'Operation Consultation',
    'Surgery recommended',
    4,
    38,
    'MRI_report.jpg'
),
(
    2,
    'Dr. Natalie Carter',
    'Female',
    'dr.carter@example.com',
    '+49-2200000022',
    '2025-02-20',
    '14:00',
    'Routine Check-up',
    'Prescribed medication for hypertension',
    5,
    42,
    'Blood_test.pdf'
),
(
    4,
    'Dr. Samantha Green',
    'Female',
    'dr.green@example.com',
    '+492222222222',
    '2025-02-22',
    '15:00',
    'Pediatrics',
    'Pediatric consultation',
    3,
    10,
    'pediatric_assessment.png'
),
(
    5,
    'Dr. David Kim',
    'Male',
    'dr.kim@example.com',
    '+493333333333',
    '2025-02-25',
    '16:00',
    'Post-op follow-up',
    'Physical therapy',
    4,
    38,
    'Post-op_Xray.jpg'
),
(
    2,
    'Dr. Natalie Carter',
    'Female',
    'dr.carter@example.com',
    '+49-2200000022',
    '2025-02-23',
    '17:00',
    'Preventive Care',
    'Preventive care advice',
    2,
    40,
    'wellness_checkup_report.pdf'
);
-- ----------------------------------------------XXXXXXXXXXXXXXXXXXXXXXXXX-----------------------------------------------------------------


###----------- Below is a single INSERT statement that adds all eight further records into the patient_detail_record table ---------------###

INSERT INTO patient_detail_record (
    patient_id,
    patient_name,
    patient_gender,
    patient_email,
    patient_phone,
    patient_age,
    patient_date_of_visit,
    purpose_of_visit,
    diagnosis_recommendation,
    patient_medical_docs,
    doctor_id
)
VALUES
(
    2,
    'Jane Smith',
    'Female',
    'jane.smith@example.com',
    '+49-1111111111',
    40,
    '2025-02-10',
    'Follow-up Consultation',
    'Rest and hydration',
    'ECG_report.pdf',
    2
),
(
    3,
    'Alice Johnson',
    'Female',
    'alice.johnson@example.com',
    '+49-5555555555',
    10,
    '2025-02-15',
    'Examination',
    'Follow-up and further tests',
    'Examination_report.pdf',
    1
),
(
    4,
    'Bob Brown',
    'Male',
    'bob.brown@example.com',
    '+49-2222222222',
    38,
    '2025-02-17',
    'Operation Consultation',
    'Surgery recommended',
    'MRI_report.jpg',
    3
),
(
    5,
    'Charlie Davis',
    'Male',
    'charlie.davis@example.com',
    '+49-3333333333',
    42,
    '2025-02-20',
    'Prescribed medication for hypertension',
    'Routine Check-up',
    'Blood_test.pdf',
    2
),
(
    1,
    'John Doe',
    'Male',
    'john.doe@example.com',
    '+49-1234567890',
    45,
    '2025-02-15',
    'General Consultation',
    'Take medication as prescribed',
    'Blood Report.pdf',
    1
),
(
    3,
    'Alice Johnson',
    'Female',
    'alice.johnson@example.com',
    '+49-5555555555',
    10,
    '2025-02-22',
    'Pediatrics',
    'Pediatric consultation',
    'pediatric_assessment.png',
    4
),
(
    4,
    'Bob Brown',
    'Male',
    'bob.brown@example.com',
    '+49-2222222222',
    38,
    '2025-02-25',
    'Post-op follow-up',
    'Physical therapy',
    'Post-op_Xray.jpg',
    5
),
(
    2,
    'Jane Smith',
    'Female',
    'jane.smith@example.com',
    '+49-1111111111',
    40,
    '2025-02-23',
    'Preventive Care',
    'Preventive care advice',
    'wellness_checkup_report.pdf',
    2
);
-- -------------------------------------XXXXXXXXXXXXXXXXXXXXXXX--------------------------------------------------------------------------------------------


###--------------- Below is an example INSERT statement that creates vital records for each patient visit ---------------####

INSERT INTO self_vitals_records_data (
    patient_id,
    patient_name,
    age,
    height,
    weight,
    gender,
    blood_type,
    blood_glucose,
    blood_pressure,
    body_temp,
    heart_rate,
    oxygen_saturation,
    respiratory_rate,
    date_of_vital_record,
    time_of_vital_record
)
VALUES
## Patient 1: John Doe (First Visit on 2025-02-08) - Already inserted for this one
# Patient 2: Jane Smith (2025-02-10)
(
    2,
    'Jane Smith',
    40,
    165,
    60,
    'Female',
    'A-',
    105,
    110,
    36.8,
    72,
    95,
    18,
    '2025-02-10',
    '09:00'
),
# Patient 3: Alice Johnson (2025-02-15)
(
    3,
    'Alice Johnson',
    10,
    140,
    35,
    'Female',
    'O+',
    88,
    100,
    36.4,
    85,
    99,
    20,
    '2025-02-15',
    '10:15'
),
# Patient 4: Bob Brown (2025-02-17)
(
    4,
    'Bob Brown',
    38,
    180,
    85,
    'Male',
    'AB+',
    140,
    150,
    37.2,
    90,
    96,
    22,
    '2025-02-17',
    '11:45'
),
# Patient 5: Charlie Davis (2025-02-20)
(
    5,
    'Charlie Davis',
    42,
    175,
    78,
    'Male',
    'B+',
    110,
    130,
    36.7,
    70,
    94,
    16,
    '2025-02-20',
    '14:00'
),
# Patient 1: John Doe (Second Visit on 2025-02-15)
(
    1,
    'John Doe',
    45,
    170,
    72,
    'Male',
    'B+',
    92,
    125,
    36.6,
    80,
    98,
    17,
    '2025-02-15',
    '09:10'
),
# Patient 3: Alice Johnson (2025-02-22)
(
    3,
    'Alice Johnson',
    10,
    140,
    35,
    'Female',
    'O+',
    100,
    105,
    36.5,
    88,
    99,
    19,
    '2025-02-22',
    '10:45'
),
# Patient 4: Bob Brown (2025-02-25)
(
    4,
    'Bob Brown',
    38,
    180,
    85,
    'Male',
    'AB+',
    125,
    135,
    36.9,
    78,
    95,
    20,
    '2025-02-25',
    '15:20'
),
# Patient 2: Jane Smith (2025-02-23)
(
    2,
    'Jane Smith',
    40,
    165,
    60,
    'Female',
    'A-',
    95,
    115,
    36.6,
    76,
    96,
    16,
    '2025-02-23',
    '11:30'
);

##--- Now, after inserting vital values, Calling stored procedure to update the vital status columns ----------###
# Stored procedure UpdateVitalsStatusForPatient is defined to accept one parameter (e.g., patient_id)
CALL UpdateVitalsStatusForPatient(1);   
CALL UpdateVitalsStatusForPatient(2);
CALL UpdateVitalsStatusForPatient(3);
CALL UpdateVitalsStatusForPatient(4);
CALL UpdateVitalsStatusForPatient(5);

-- ----------------------------------------------------XXXXXXXXXXXXXXXXXXXXXXXXXXXX---------------------------------------------------------------



####------------- Below is an example INSERT statement that adds prescription records for the remaining patients IDs (2, 3, 4, and 5) in the prescriptions_data table ------------------####

INSERT INTO prescriptions_data (
    patient_id,
    patient_name,
    medicine_name,
    date_of_record,
    prescription_start_date,
    prescription_end_date,
    prescription_recommended_x_times_per_day
)
VALUES
# Patient 2: Jane Smith
(
    2,
    'Jane Smith',
    'Ibuprofen',
    '2025-02-10',    -- date when the prescription is recorded
    '2025-02-11',    -- prescription start date
    '2025-02-14',    -- prescription end date
    2                -- recommended times per day
),
# Patient 3: Alice Johnson
(
    3,
    'Alice Johnson',
    'Amoxicillin',
    '2025-02-15',
    '2025-02-16',
    '2025-02-18',
    1
),
# Patient 4: Bob Brown
(
    4,
    'Bob Brown',
    'Analgesic',
    '2025-02-17',
    '2025-02-18',
    '2025-02-20',
    2
),
# Patient 5: Charlie Davis
(
    5,
    'Charlie Davis',
    'Metoprolol',
    '2025-02-20',
    '2025-02-21',
    '2025-02-25',
    3
);

## Now, after inserting vital values, Calling stored procedure to update the dosage frequency slots per day---------------------------------------------------------------------
# Stored procedure UpdatePrescriptionSlots is defined to accept one parameter (e.g., patient_id)
CALL UpdatePrescriptionSlots(2);   
CALL UpdatePrescriptionSlots(3);
CALL UpdatePrescriptionSlots(4); 
CALL UpdatePrescriptionSlots(5); 
CALL UpdatePrescriptionSlots(1);

-- -------------------------------------------------------XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX----------------------------------------------------------------------------------------------------


####------------- Below is an INSERT statement that adds appointment records for each relevant doctor_id and patient_id pair found in database tables doctor_record and patient_detail_record--------------####

INSERT INTO appointments (
    doctor_id,
    patient_id,
    appointment_date,
    appointment_time,
    appointment_status,
    reason_for_visit,
    additional_notes
)
VALUES
# Appointment 1: Doctor 1 (Dr. Christopher Lee) with Patient 1 (John Doe) on 2025-02-08   -- already inserted.
# Appointment 2: Doctor 2 (Dr. Natalie Carter) with Patient 2 (Jane Smith) on 2025-02-10
(
    2,
    2,
    '2025-02-10',
    '10:00:00',
    'Completed',
    'Follow-up Consultation',
    'No additional notes'
),
# Appointment 3: Doctor 1 (Dr. Christopher Lee) with Patient 3 (Alice Johnson) on 2025-02-15
(
    1,
    3,
    '2025-02-15',
    '12:30:00',
    'Completed',
    'Examination',
    'Bring prior test results'
),
# Appointment 4: Doctor 3 (Dr. Alex Carry) with Patient 4 (Bob Brown) on 2025-02-17
(
    3,
    4,
    '2025-02-17',
    '13:00:00',
    'Scheduled',
    'Operation Consultation',
    'Arrive fasting for surgery prep'
),
# Appointment 5: Doctor 2 (Dr. Natalie Carter) with Patient 5 (Charlie Davis) on 2025-02-20
(
    2,
    5,
    '2025-02-20',
    '14:00:00',
    'Completed',
    'Routine Check-up',
    'No additional notes'
),
# Appointment 6: Doctor 1 (Dr. Christopher Lee) with Patient 1 (John Doe) on 2025-02-15
(
    1,
    1,
    '2025-02-15',
    '09:00:00',
    'Scheduled',
    'General Consultation',
    'Follow-up appointment'
),
# Appointment 7: Doctor 4 (Dr. Samantha Green) with Patient 3 (Alice Johnson) on 2025-02-22
(
    4,
    3,
    '2025-02-22',
    '15:00:00',
    'Scheduled',
    'Pediatrics',
    'Bring pediatric_assessment.png'
),
# Appointment 8: Doctor 5 (Dr. David Kim) with Patient 4 (Bob Brown) on 2025-02-25
(
    5,
    4,
    '2025-02-25',
    '16:00:00',
    'Scheduled',
    'Post-op follow-up',
    'Discuss therapy plan'
),
# Appointment 9: Doctor 2 (Dr. Natalie Carter) with Patient 2 (Jane Smith) on 2025-02-23
(
    2,
    2,
    '2025-02-23',
    '11:30:00',
    'Cancelled',
    'Preventive Care',
    'Reschedule if needed'
);

-- ----------------------------------------------------------------XXXXXXXXXXXXXXXXXXXXXXXXXX----------------------------------------------------------------------------------------------------------------------------



