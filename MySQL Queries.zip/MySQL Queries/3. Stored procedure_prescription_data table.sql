

DELIMITER //

CREATE PROCEDURE UpdatePrescriptionSlots(IN p_patient_id BIGINT)
BEGIN
    ## Update Prescription Slots Based on Recommended Times Per Day
    UPDATE prescriptions_data
    SET 
        morning_slot = 
            CASE 
                WHEN prescription_recommended_x_times_per_day >= 1 THEN 'Morning dose: 8:00–10:00 AM'
                ELSE 'Morning dse: Not recommended'
            END,
        afternoon_slot = 
            CASE 
                WHEN prescription_recommended_x_times_per_day >= 2 THEN 'Afternoon dose: 12:00–2:00 PM'
                ELSE 'Afternoon dose: Not recommended'
            END,
        evening_slot = 
            CASE 
                WHEN prescription_recommended_x_times_per_day = 3 THEN 'Evening dose: 7:00–9:00 PM'
                ELSE 'Evening dose: Not recommended'
            END
    WHERE patient_id = p_patient_id;
END //

DELIMITER ;
