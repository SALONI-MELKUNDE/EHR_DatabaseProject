

//* Database creation *//-------------------------------------------------------------
//create a database named ehr_portal_mongo
use ('ehr_portal_mongo');



// Create a collection named patient_data_table
db.createCollection("patient_data_table", {
    validator: {
      $jsonSchema: {
        bsonType: "object",
        required: ["patient_id", "date_of_visit", "time_of_visit"],
        properties: {
          patient_id: {
            bsonType: "int",
            description: "must be an integer"
          },
          date_of_visit: {
            bsonType: "date",
            description: "must be a BSON date"
          },
          time_of_visit: {
            bsonType: "string",
            pattern: "^([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$",
            description: "must be a valid time in HH:MM:SS format"
          }
        }
      }
    },
    validationLevel: "strict"
  });




// Insert a document into the collection
db.patient_data_table.insertOne({
  patient_id: 1,
  date_of_visit: new Date("2025-02-08"),
  time_of_visit: "08:00:00"
});


//inserting multiple records
use('ehr_portal_mongo');
db.patient_data_table.insertMany([
  {
    patient_id: 2,
    date_of_visit: new Date("2025-02-10"),
    time_of_visit: "09:00:00"
  },
  {
    patient_id: 3,
    date_of_visit: new Date("2025-02-15"),
    time_of_visit: "12:30:00"
  }
]);



//query(get) the data from the collection
use ('ehr_portal_mongo')
db.patient_data_table.find().pretty();


//query(get) the data from the collection based on patient_id
use ('ehr_portal_mongo')
db.patient_data_table.findOne({ patient_id: 1 });

//query(get) the data from the collection for all patient_id's
use('ehr_portal_mongo');
db.patient_data_table.find({ patient_id: { $in: [1, 2, 3] } }).pretty();



// mongofiles command should be run on the cmd(command prompt) to upload the files to the gridFS:=

//1. >mongofiles --version
//2. >mongofiles --db=ehr_portal_mongo put blood_report.pdf \  --local "C:\Users\salon\Mongodb_project\upload_to_mongofiles\blood_report.pdf"
//3. >mongofiles --db=ehr_portal_mongo put ECG_report.pdf \  --local "C:\Users\salon\Mongodb_project\upload_to_mongofiles\ECG_report.pdf"
//4. >mongofiles --db=ehr_portal_mongo put pediatric_report.jpg \  --local "C:\Users\salon\Mongodb_project\upload_to_mongofiles\pediatric_report.jpg"
//5. >mongofiles --db=ehr_portal_mongo list



//finding the file from the collection
use ('ehr_portal_mongo')
db.fs.files.findOne({ filename: "blood_report.pdf" });


//finding the file from the collection

use ('ehr_portal_mongo')
db.fs.files.findOne({ filename: "ECG_report.pdf" });


//finding the file from the collection
use ('ehr_portal_mongo')
db.fs.files.findOne({ filename: "pediatric_report.jpg" });




// use ('ehr_portal_mongo')
// const fileDoc = db.fs.files.findOne({ filename: "blood_report.pdf" }); fileDoc;

// use ('ehr_portal_mongo')
// const fileDoc = db.fs.files.findOne({ filename: "ECG_report.pdf" }); fileDoc;

// use ('ehr_portal_mongo')
// const fileDoc = db.fs.files.findOne({ filename: "pediatric_report.jpg" }); fileDoc;



// mongofiles command should be run on the cmd:=

//6. >mongofiles --db=ehr_portal_mongo get "blood_report.pdf" ^  --local "C:\\Users\\salon\\Mongodb_project\\download_from_mongofiles\\blood_report.pdf"
//7. >mongofiles --db=ehr_portal_mongo get "ECG_report.pdf" ^  --local "C:\\Users\\salon\\Mongodb_project\\download_from_mongofiles\\ECG_report.pdf"
//8. >mongofiles --db=ehr_portal_mongo get "pediatric_report.jpg" ^  --local "C:\\Users\\salon\\Mongodb_project\\download_from_mongofiles\\pediatric_report.jpg"




// Finding the patient document for patient_id = 1 and adding a file reference field
use ('ehr_portal_mongo')
var fileDoc = db.fs.files.findOne({ filename: "blood_report.pdf" }); //finding the file from the collection

if (fileDoc) {
  db.patient_data_table.updateOne(
    { patient_id: 1 },
    { $set: { fileReference: fileDoc._id } }
  );
  print("Patient record updated with file reference:", fileDoc._id);
} else {
  print("File not found!");
}


// To verify, retrieve the updated patient document
use ('ehr_portal_mongo')
var patient = db.patient_data_table.findOne({ patient_id: 1 });
print("Updated patient document:");
printjson(patient);

//to view the linked file document using the reference
use ('ehr_portal_mongo')
if (patient && patient.fileReference) {
  var linkedFile = db.fs.files.findOne({ _id: patient.fileReference });
  print("Linked file document:");
  printjson(linkedFile);
}



// Finding the patient document for patient_id = 2 and adding a file reference field
use ('ehr_portal_mongo')
var fileDoc = db.fs.files.findOne({ filename: "ECG_report.pdf" }); //finding the file from the collection

if (fileDoc) {
  // Update the patient document for patient_id = 2 by adding a file reference field
  db.patient_data_table.updateOne(
    { patient_id: 2 },
    { $set: { fileReference: fileDoc._id } }
  );
  print("Patient record updated with file reference:", fileDoc._id);
} else {
  print("File not found!");
}



// To verify, retrieve the updated patient document
use ('ehr_portal_mongo')
var patient = db.patient_data_table.findOne({ patient_id: 2 });
print("Updated patient document:");
printjson(patient);

//to view the linked file document using the reference
use ('ehr_portal_mongo')
if (patient && patient.fileReference) {
  var linkedFile = db.fs.files.findOne({ _id: patient.fileReference });
  print("Linked file document:");
  printjson(linkedFile);
}




// Finding the patient document for patient_id = 3 and adding a file reference field
use ('ehr_portal_mongo')
var fileDoc = db.fs.files.findOne({ filename: "pediatric_report.jpg" }); //finding the file from the collection

if (fileDoc) {
  // Update the patient document for patient_id = 3 by adding a file reference field
  db.patient_data_table.updateOne(
    { patient_id: 3 },
    { $set: { fileReference: fileDoc._id } }
  );
  print("Patient record updated with file reference:", fileDoc._id);
} else {
  print("File not found!");
}



// To verify, retrieve the updated patient document
use ('ehr_portal_mongo')
var patient = db.patient_data_table.findOne({ patient_id: 3 });
print("Updated patient document:");
printjson(patient);

//to view the linked file document using the reference
use ('ehr_portal_mongo')
if (patient && patient.fileReference) {
  var linkedFile = db.fs.files.findOne({ _id: patient.fileReference });
  print("Linked file document:");
  printjson(linkedFile);
}




//updating the correct record, in place of wrong record
use('ehr_portal_mongo');

db.patient_data_table.updateOne(
  { patient_id: 3 }, // matching condition
  {
    $set: {
      date_of_visit: new Date("2025-02-22"),
      time_of_visit: "15:00:00"
    }
  }
);



// Verify the update
use('ehr_portal_mongo');
db.patient_data_table.find({ patient_id: 3 }).pretty();

// To verify, you can run:
use('ehr_portal_mongo')
db.patient_data_table.find();




//deleting the file from the collection and verify for the patient_id = 4


// Insert a document into the collection
use('ehr_portal_mongo');
db.patient_data_table.insertOne({
  patient_id: 4,
  date_of_visit: new Date("2025-02-25"),
  time_of_visit: "16:00:00"
});


//query(get) the data from the collection based on patient_id
use ('ehr_portal_mongo')
db.patient_data_table.findOne({ patient_id: 4 });



// mongofiles command should be run on the cmd:=

//mongofiles --db=ehr_portal_mongo put Xray.jpg \  --local "C:\Users\salon\Mongodb_project\upload_to_mongofiles\Xray.jpg"
//mongofiles --db=ehr_portal_mongo list
//mongofiles --db=ehr_portal_mongo get "Xray.jpg" ^  --local "C:\\Users\\salon\\Mongodb_project\\download_from_mongofiles\\Xray.jpg"


//finding the file from the collection
use ('ehr_portal_mongo')
db.fs.files.findOne({ filename: "Xray.jpg" });



// Finding the patient document for patient_id = 4 and adding a file reference field
use ('ehr_portal_mongo')
var fileDoc = db.fs.files.findOne({ filename: "Xray.jpg" }); //finding the file from the collection

if (fileDoc) {
  db.patient_data_table.updateOne(
    { patient_id: 4 },
    { $set: { fileReference: fileDoc._id } }
  );
  print("Patient record updated with file reference:", fileDoc._id);
} else {
  print("File not found!");
}


// To verify, retrieve the updated patient document
use ('ehr_portal_mongo')
var patient = db.patient_data_table.findOne({ patient_id: 4 });
print("Updated patient document:");
printjson(patient);

//to view the linked file document using the reference
use ('ehr_portal_mongo')
if (patient && patient.fileReference) {
  var linkedFile = db.fs.files.findOne({ _id: patient.fileReference });
  print("Linked file document:");
  printjson(linkedFile);
}


// To verify, you can run:
use('ehr_portal_mongo')
db.patient_data_table.find();




//find the patient document 
use('ehr_portal_mongo');
var patient = db.patient_data_table.findOne({ patient_id: 4 });
print("Patient document for patient_id = 4:");
printjson(patient);

//delete the file from the gridFS for the patient_id = 4
if (patient && patient.fileReference) {
  print("Deleting GridFS file for patient_id = 4...");

  var chunksResult = db.fs.chunks.deleteMany({ files_id: patient.fileReference });
  print("Deleted file chunks count:", chunksResult.deletedCount);

  var fileResult = db.fs.files.deleteOne({ _id: patient.fileReference });
  print("Deleted file document count:", fileResult.deletedCount);
} else {
  print("No fileReference found for patient_id = 4.");
}

//delete the patiemt document for the patient_id = 4
var patientResult = db.patient_data_table.deleteOne({ patient_id: 4 });
print("Deleted patient document count:", patientResult.deletedCount);

//verfiy the deletion
print("Verifying deletion for patient_id = 4:");
printjson(db.patient_data_table.findOne({ patient_id: 4 }));










//################################################################################################//



//create a database named ehr_portal_mongo
use ('ehr_portal_mongo');




// Create a collection named doctor_data_table
use('ehr_portal_mongo');

db.createCollection("doctor_data_table", {
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: ["doctor_id", "date_of_visit", "time_of_visit"],
      properties: {
        doctor_id: {
          bsonType: "int",
          description: "must be an integer"
        },
        date_of_visit: {
          bsonType: "date",
          description: "must be a BSON date"
        },
        time_of_visit: {
          bsonType: "string",
          pattern: "^([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$",
          description: "must be a valid time in HH:MM:SS format"
        }
      }
    }
  },
  validationLevel: "strict"
});



// Insert a document into the collection
use('ehr_portal_mongo');

db.doctor_data_table.insertMany([
  {
    doctor_id: 1,
    date_of_visit: new Date("2025-02-08"),
    time_of_visit: "08:00:00"
  },
  {
    doctor_id: 2,
    date_of_visit: new Date("2025-02-10"),
    time_of_visit: "11:00:00"
  },
  {
    doctor_id: 4,
    date_of_visit: new Date("2025-02-22"),
    time_of_visit: "15:00:00"
  }
]);



// To verify, you can run:
use('ehr_portal_mongo')
db.doctor_data_table.find().pretty();





//lookup the doctor data for the patient data
use('ehr_portal_mongo');

db.patient_data_table.aggregate([
  {
    $lookup: {
      from: "doctor_data_table",
      let: { 
        p_date: "$date_of_visit",
        p_time: "$time_of_visit"
      },
      pipeline: [
        {
          $match: {
            $expr: {
              $and: [
                { $eq: ["$date_of_visit", "$$p_date"] },
                { $eq: ["$time_of_visit", "$$p_time"] }
              ]
            }
          }
        }
      ],
      as: "matchingDoctors"
    }
  }
]).pretty();